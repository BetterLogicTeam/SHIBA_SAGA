
import Saga_header from './components/Saga_header/Saga_header';
import Sage_landing from './components/Sage_landing/Sage_landing';
import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
    <div className="App">
    <Saga_header/>
  
    </div>
  );
}

export default App;
